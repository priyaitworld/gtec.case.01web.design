    function btnRed_onclick(){
        alert('Pressed:Red button');
    }

    function btnGreen_onclick(){
        alert('Pressed:Green button');
    }

    function btnblue_onclick(){
        alert('pressed:blue button');
    }
